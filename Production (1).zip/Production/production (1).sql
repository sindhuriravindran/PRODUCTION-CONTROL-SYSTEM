-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2020 at 10:53 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `production`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `aid` int(11) NOT NULL,
  `ename` varchar(25) NOT NULL,
  `date` date NOT NULL,
  `mrngshift` varchar(20) NOT NULL,
  `noonshift` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`aid`, `ename`, `date`, `mrngshift`, `noonshift`) VALUES
(7, '2', '2020-03-06', 'ABSENT', 'PRESENT'),
(8, '1', '2020-06-02', 'ABSENT', 'PRESENT'),
(9, '4', '2020-03-03', 'ABSENT', 'PRESENT'),
(10, '7', '2020-04-10', 'PRESENT', 'PRESENT'),
(11, '7', '2020-04-11', 'ABSENT', 'ABSENT');

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custreg`
--

CREATE TABLE `custreg` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `caddr` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobileno` varchar(11) NOT NULL,
  `credlmt` int(11) NOT NULL,
  `days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `custreg`
--

INSERT INTO `custreg` (`cid`, `cname`, `caddr`, `email`, `mobileno`, `credlmt`, `days`) VALUES
(1, 'achu', '	sdfsscszcsvsxv			', 'achu@gmail.com', '24242342', 20000, 25),
(2, 'Ali', 'dfgdgdfgdffg		', 'ali@gmail.com', '9674512568', 12000, 10),
(3, 'navin', 'kjhgfds', 'navin@gmail.com', '98765432', 20000, 15),
(4, 'GM Customer', 'Wayand', 'gm.cus@gmail.com', '9746987732', 25000, 20);

-- --------------------------------------------------------

--
-- Table structure for table `daybook`
--

CREATE TABLE `daybook` (
  `id` int(11) NOT NULL,
  `e_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `des` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daybook`
--

INSERT INTO `daybook` (`id`, `e_id`, `date`, `des`) VALUES
(1, 7, '2020-04-10', '9-12 cleaining\r\n2-4 report '),
(2, 1, '2020-04-10', '9-12 submit all \r\n2-4 shift'),
(3, 1, '2020-04-10', '9-12 submit all \r\n2-4 shift');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `id` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `items` varchar(50) NOT NULL,
  `des` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`id`, `eid`, `items`, `des`, `status`) VALUES
(1, 1, 'Raw Meterilas. other', 'crry cre', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2020-03-03 12:48:27.315736'),
(2, 'auth', '0001_initial', '2020-03-03 12:48:29.151122'),
(3, 'admin', '0001_initial', '2020-03-03 12:48:39.487208'),
(4, 'admin', '0002_logentry_remove_auto_add', '2020-03-03 12:48:41.488016'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2020-03-03 12:48:41.529904'),
(6, 'contenttypes', '0002_remove_content_type_name', '2020-03-03 12:48:42.607044'),
(7, 'auth', '0002_alter_permission_name_max_length', '2020-03-03 12:48:42.879314'),
(8, 'auth', '0003_alter_user_email_max_length', '2020-03-03 12:48:43.063177'),
(9, 'auth', '0004_alter_user_username_opts', '2020-03-03 12:48:43.141900'),
(10, 'auth', '0005_alter_user_last_login_null', '2020-03-03 12:48:44.265079'),
(11, 'auth', '0006_require_contenttypes_0002', '2020-03-03 12:48:44.296659'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2020-03-03 12:48:44.372245'),
(13, 'auth', '0008_alter_user_username_max_length', '2020-03-03 12:48:44.554408'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2020-03-03 12:48:44.711636'),
(15, 'auth', '0010_alter_group_name_max_length', '2020-03-03 12:48:44.910987'),
(16, 'auth', '0011_update_proxy_permissions', '2020-03-03 12:48:44.992847'),
(17, 'sessions', '0001_initial', '2020-03-03 12:48:45.385916');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('47zrlw9cb0v4ok3hdge59q6e7jp3b0dc', 'NTI0MTMyMWI1ZTNkNDAzZTVhNWFmMmFhM2MyMmYwNmY0NTI4MWQzZDp7ImFkbWluIjoxLCJtYW5hZ2VyIjoxfQ==', '2020-03-17 16:31:11.751687'),
('4a3gk93318e2oef1qgd79n9qrwgb7kfd', 'MmVmMDE1Y2YyYjE2NDJmY2E2MzgzZjZhMjllNTkxOWRlYzk3NGIyNzp7InVpZCI6MX0=', '2020-04-26 08:40:37.490772'),
('iipoymrng4uuhxoyqk5vzamhdj12k8dr', 'YTY1ZjU3NDYyYzE2MjkxOTMyYTRmYzUwODY2NDY2ZDkyY2RiNTI5ZTp7ImFkbWluIjoxLCJtYW5hZ2VyIjoxLCJlbXBsb3llZSI6MX0=', '2020-03-24 07:49:19.256401');

-- --------------------------------------------------------

--
-- Table structure for table `employreg`
--

CREATE TABLE `employreg` (
  `eid` int(11) NOT NULL,
  `ename` varchar(50) NOT NULL,
  `eaddr` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `basicpay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employreg`
--

INSERT INTO `employreg` (`eid`, `ename`, `eaddr`, `phone`, `email`, `type`, `basicpay`) VALUES
(1, 'ali', '	sdsfsddscdscsca			', '0', '89645345311', 'welder', 5000),
(2, 'navin', '				vhvvhgfcgf', '0', '9846755398', 'clerk', 3000),
(3, 'theertha', 'axhgavxabajxan		', '0', '9567341209', 'clerk', 10000),
(4, 'theertha', '	asxcvbnm			', '2147483647', 'theertha@gmail.com', 'Technician', 516),
(5, 'theertha', '	dfgh			', '9567341209', 'ammu123@gmail.com', 'Technician', 10000),
(6, 'abina', '		lkjhgf		', '98765432', 'abinq@gmail.com', 'Labour', 1000),
(7, 'GM Emp', 'Wayanad				', '9746987732', 'gm.emp@gmail.com', 'Technician', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `exp_amt` varchar(50) NOT NULL,
  `details` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `eid`, `exp_amt`, `details`, `date`) VALUES
(1, 1, '12000', 'Due to High recommaned', '2020-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `leaveentry`
--

CREATE TABLE `leaveentry` (
  `lid` int(11) NOT NULL,
  `ename` int(25) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaveentry`
--

INSERT INTO `leaveentry` (`lid`, `ename`, `date`, `reason`) VALUES
(1, 1, '2020-01-24', '	fever			'),
(2, 7, '2020-02-03', 'fever			'),
(3, 1, '2020-01-07', 'hospitalized	'),
(4, 4, '2020-03-02', 'marriage		'),
(5, 7, '2020-03-04', '		fever		'),
(7, 1, '2020-04-12', 'Marriage Funcion');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `uid`, `username`, `password`, `type`) VALUES
(1, 1, 'admin', 'admin', 'admin'),
(2, 1, 'man', '123', 'manager'),
(3, 1, 'emp', '123', 'employee'),
(4, 7, 'gm', 'gm', 'employee');

-- --------------------------------------------------------

--
-- Table structure for table `otentry`
--

CREATE TABLE `otentry` (
  `oid` int(11) NOT NULL,
  `ename` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `hours` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otentry`
--

INSERT INTO `otentry` (`oid`, `ename`, `date`, `hours`) VALUES
(1, 'ali', '2020-03-03', 3),
(2, 'theertha', '2020-03-13', 5),
(3, 'abina', '2020-03-05', 5),
(4, 'GM', '2020-04-11', 2),
(5, 'theertha', '2020-04-11', 2),
(6, 'theertha', '2020-04-11', 2);

-- --------------------------------------------------------

--
-- Table structure for table `other_income`
--

CREATE TABLE `other_income` (
  `id` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `in_amt` varchar(50) NOT NULL,
  `des` varchar(50) NOT NULL,
  `ddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other_income`
--

INSERT INTO `other_income` (`id`, `eid`, `in_amt`, `des`, `ddate`) VALUES
(1, 1, '20000', 'Free Credit', '2020-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `purchaseentry`
--

CREATE TABLE `purchaseentry` (
  `peid` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `rid` int(110) NOT NULL,
  `quantity` varchar(110) NOT NULL,
  `cgst` varchar(110) NOT NULL,
  `igst` varchar(110) NOT NULL,
  `total` varchar(110) NOT NULL,
  `discount` varchar(110) NOT NULL,
  `gstno` varchar(110) NOT NULL,
  `py_ty` varchar(50) NOT NULL,
  `due_date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseentry`
--

INSERT INTO `purchaseentry` (`peid`, `vid`, `date`, `rid`, `quantity`, `cgst`, `igst`, `total`, `discount`, `gstno`, `py_ty`, `due_date`, `status`) VALUES
(4, 2, '2020-04-13', 2, '500', 'GF642', 'GT326', '120000', '1000', 'G324', 'cash', '2020-05-08', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder`
--

CREATE TABLE `purchaseorder` (
  `orderno` int(11) NOT NULL,
  `date` date NOT NULL,
  `rname` varchar(25) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseorder`
--

INSERT INTO `purchaseorder` (`orderno`, `date`, `rname`, `quantity`, `status`) VALUES
(7, '2020-02-13', 'Steel', '200kg', 'pending'),
(8, '2020-03-11', 'zinc', '200', 'pending'),
(13, '2020-04-09', 'Steel', '3000', 'pending'),
(14, '2020-04-09', 'Steel', '3000', 'approve'),
(15, '2020-04-09', 'copper', '2', 'reject');

-- --------------------------------------------------------

--
-- Table structure for table `rawreg`
--

CREATE TABLE `rawreg` (
  `rid` int(11) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `description` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rawreg`
--

INSERT INTO `rawreg` (`rid`, `rname`, `description`) VALUES
(1, 'aluminium', 'hfjgghjgjjfffghkh'),
(2, 'zinc', 'stdfjhgjh'),
(3, 'copper', 'yfuuiiyi'),
(4, 'zinc', 'yrtddthg'),
(5, 'aluminium', 'oiuytrew'),
(6, 'Steel', 'simple but powerfull');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `amt` varchar(50) NOT NULL,
  `billno` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`id`, `cid`, `amt`, `billno`, `date`) VALUES
(1, 4, '20000', 'BILL004', '2020-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `salaryset`
--

CREATE TABLE `salaryset` (
  `stid` int(11) NOT NULL,
  `emp_type` varchar(20) NOT NULL,
  `empid` int(11) NOT NULL,
  `basicpay` int(11) NOT NULL,
  `allowances` int(11) NOT NULL,
  `leavepmn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salaryset`
--

INSERT INTO `salaryset` (`stid`, `emp_type`, `empid`, `basicpay`, `allowances`, `leavepmn`) VALUES
(1, 'welder', 1, 10000, 1000, 5),
(2, 'Supervisor', 7, 12000, 1200, 5);

-- --------------------------------------------------------

--
-- Table structure for table `salesentry`
--

CREATE TABLE `salesentry` (
  `seid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `billno` varchar(110) NOT NULL,
  `date` varchar(110) NOT NULL,
  `product` varchar(110) NOT NULL,
  `quantity` varchar(110) NOT NULL,
  `cgst` varchar(110) NOT NULL,
  `igst` varchar(110) NOT NULL,
  `total` varchar(110) NOT NULL,
  `discount` varchar(110) NOT NULL,
  `gstno` varchar(110) NOT NULL,
  `pay_ty` varchar(50) NOT NULL,
  `due_date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesentry`
--

INSERT INTO `salesentry` (`seid`, `cid`, `billno`, `date`, `product`, `quantity`, `cgst`, `igst`, `total`, `discount`, `gstno`, `pay_ty`, `due_date`, `status`) VALUES
(9, 2, 'BILL_002', '2020-04-13', '2', '500kg', 'CGST1235', 'IGHST6312', '1232810', '1200', 'GST12312', 'credit', '15', 'pending'),
(10, 3, 'BILL_006', '2020-04-13', '1', '643', '636', '6', '67', '36', '67', 'credit', '2020-04-18', 'pending'),
(11, 2, 'BILL_002', '2020-04-13', '2', '65', '56', '65', '6', '6', '65', 'cash', '2020-04-23', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `sales_master`
--

CREATE TABLE `sales_master` (
  `id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `t_amt` int(11) NOT NULL,
  `date` date NOT NULL,
  `pay_type` varchar(50) NOT NULL,
  `due_date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_master`
--

INSERT INTO `sales_master` (`id`, `s_id`, `cus_id`, `t_amt`, `date`, `pay_type`, `due_date`, `status`) VALUES
(5, 7, 1, 12311, '2020-04-13', 'cash', '15', 'success'),
(6, 8, 1, 12311, '2020-04-13', 'cash', '15', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `sizechart`
--

CREATE TABLE `sizechart` (
  `sid` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `stype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sizechart`
--

INSERT INTO `sizechart` (`sid`, `size`, `stype`) VALUES
(1, '1000cm', 'aluminium'),
(2, '1000cm', 'aluminium'),
(3, '2000cm', 'aluminium'),
(4, '100', 'aluminium'),
(5, '12000CM', 'STEEL');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `quantity` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `rid`, `quantity`) VALUES
(1, 1, '10000 KG');

-- --------------------------------------------------------

--
-- Table structure for table `vehiclereg`
--

CREATE TABLE `vehiclereg` (
  `vehid` int(11) NOT NULL,
  `vehno` varchar(30) NOT NULL,
  `type` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiclereg`
--

INSERT INTO `vehiclereg` (`vehid`, `vehno`, `type`, `status`) VALUES
(1, 'KL 13 AD 7799', 'lorry', 'available'),
(2, 'KL 13 AD 7799', 'van', 'available'),
(3, 'KL GFF', 'LORRY', 'available'),
(4, 'KL 12 L 5905', 'SUV', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `vehicletrip`
--

CREATE TABLE `vehicletrip` (
  `vtid` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `km` int(11) NOT NULL,
  `date` date NOT NULL,
  `des` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicletrip`
--

INSERT INTO `vehicletrip` (`vtid`, `vid`, `km`, `date`, `des`) VALUES
(1, 4, 45, '2020-04-10', 'Releif package\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `vendorpay`
--

CREATE TABLE `vendorpay` (
  `vpid` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `billno` varchar(20) NOT NULL,
  `pay_ty` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendorpay`
--

INSERT INTO `vendorpay` (`vpid`, `vid`, `amount`, `billno`, `pay_ty`, `date`) VALUES
(1, 1, 263, 'BILL004', 'cash', '2020-04-12'),
(2, 3, 236, 'BILL004', 'credit', '2020-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `vendorreg`
--

CREATE TABLE `vendorreg` (
  `Vid` int(11) NOT NULL,
  `Vname` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Officeno` varchar(20) NOT NULL,
  `Mobileno` varchar(11) NOT NULL,
  `Creditlimit` int(11) NOT NULL,
  `Days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendorreg`
--

INSERT INTO `vendorreg` (`Vid`, `Vname`, `Address`, `Email`, `Officeno`, `Mobileno`, `Creditlimit`, `Days`) VALUES
(1, 'sindri', '	hrisheekesam			', 'sindhuri@gmail.com', '04972722001', '2147483647', 25000, 25),
(2, 'ash', '	fssdfsdfsdash			', 'achu11@gmail.com', '04972722001', '2147483647', 20000, 25),
(3, 'achu', '				ghhghhh', 'achu11gmail.com', '04972722001', '2147483647', 20000, 15),
(4, 'navin', '				sdcscscdvdvsdvdsvdsvd', 'navin@gmail.com', '04972734512', '2147483647', 100000, 10),
(5, 'navin', '				sdcscscdvdvsdvdsvdsvd', 'navin@gmail.com', '04972734512', '2147483647', 100000, 10),
(6, 'rahul', 'sdcnbscskcsklcmslc', 'rahul@gmail.com', '0497235464', '987576375', 100000, 15),
(7, 'don', 'don villa			', 'don@2025', '4972722001', '987576375', 626262303, 10),
(8, 'ammu', 'jhdjshjkskskcsj				', 'ammu123@gmail.com', '04972765431', '2147483647', 100000, 15),
(9, 'ali', 'oiuytr		', 'ali@gmail.com', '049727568', '998765432', 10000, 13),
(10, 'Gm', 'Wayanad', 'gm@gmail.com', '34623', '9746987732', 231, 4);

-- --------------------------------------------------------

--
-- Table structure for table `work_or`
--

CREATE TABLE `work_or` (
  `id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `work` varchar(50) NOT NULL,
  `locaion` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `work_or`
--

INSERT INTO `work_or` (`id`, `vid`, `cid`, `work`, `locaion`, `date`, `status`) VALUES
(1, 1, 4, 'Roofing Maintnace			', 'Wayanad', '2020-04-14', 'pending'),
(2, 7, 1, 'Plumbing', 'Wayanad', '2020-04-16', 'pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `custreg`
--
ALTER TABLE `custreg`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `daybook`
--
ALTER TABLE `daybook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `employreg`
--
ALTER TABLE `employreg`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaveentry`
--
ALTER TABLE `leaveentry`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otentry`
--
ALTER TABLE `otentry`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `other_income`
--
ALTER TABLE `other_income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchaseentry`
--
ALTER TABLE `purchaseentry`
  ADD PRIMARY KEY (`peid`);

--
-- Indexes for table `purchaseorder`
--
ALTER TABLE `purchaseorder`
  ADD PRIMARY KEY (`orderno`);

--
-- Indexes for table `rawreg`
--
ALTER TABLE `rawreg`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salaryset`
--
ALTER TABLE `salaryset`
  ADD PRIMARY KEY (`stid`);

--
-- Indexes for table `salesentry`
--
ALTER TABLE `salesentry`
  ADD PRIMARY KEY (`seid`);

--
-- Indexes for table `sales_master`
--
ALTER TABLE `sales_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizechart`
--
ALTER TABLE `sizechart`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehiclereg`
--
ALTER TABLE `vehiclereg`
  ADD PRIMARY KEY (`vehid`);

--
-- Indexes for table `vehicletrip`
--
ALTER TABLE `vehicletrip`
  ADD PRIMARY KEY (`vtid`);

--
-- Indexes for table `vendorpay`
--
ALTER TABLE `vendorpay`
  ADD PRIMARY KEY (`vpid`);

--
-- Indexes for table `vendorreg`
--
ALTER TABLE `vendorreg`
  ADD PRIMARY KEY (`Vid`);

--
-- Indexes for table `work_or`
--
ALTER TABLE `work_or`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custreg`
--
ALTER TABLE `custreg`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `daybook`
--
ALTER TABLE `daybook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employreg`
--
ALTER TABLE `employreg`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leaveentry`
--
ALTER TABLE `leaveentry`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `otentry`
--
ALTER TABLE `otentry`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `other_income`
--
ALTER TABLE `other_income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `purchaseentry`
--
ALTER TABLE `purchaseentry`
  MODIFY `peid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `purchaseorder`
--
ALTER TABLE `purchaseorder`
  MODIFY `orderno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `rawreg`
--
ALTER TABLE `rawreg`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `salaryset`
--
ALTER TABLE `salaryset`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `salesentry`
--
ALTER TABLE `salesentry`
  MODIFY `seid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sales_master`
--
ALTER TABLE `sales_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sizechart`
--
ALTER TABLE `sizechart`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vehiclereg`
--
ALTER TABLE `vehiclereg`
  MODIFY `vehid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vehicletrip`
--
ALTER TABLE `vehicletrip`
  MODIFY `vtid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vendorpay`
--
ALTER TABLE `vendorpay`
  MODIFY `vpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vendorreg`
--
ALTER TABLE `vendorreg`
  MODIFY `Vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `work_or`
--
ALTER TABLE `work_or`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
