from django.shortcuts import render
from salesentry.models import Salesentry
from custreg.models import Custreg
from rawreg.models import Rawreg
from sales_master.models import SalesMaster
import datetime
from datetime import timedelta,date
from django.db import connection
# Create your views here.


def sales(request):
    task = Custreg.objects.all()
    objlist = Rawreg.objects.all()
    context = {
        'task': task,
        'objval': objlist,
    }
    if request.method == "POST":
        cus = request.POST.get("cid")
        due = Custreg.objects.get(cid=cus)
        day = due.days
        EndDate = date.today() + timedelta(days=day)
        obj = Salesentry()
        obj.cid = request.POST.get("cid")
        obj.billno = request.POST.get("billno")
        obj.date = datetime.date.today()
        obj.product = request.POST.get("product")
        obj.quantity = request.POST.get("qty")
        obj.cgst = request.POST.get("cgst")
        obj.igst = request.POST.get("igst")
        obj.total = request.POST.get("total")
        obj.discount = request.POST.get("dis")
        obj.gstno = request.POST.get("gstno")
        obj.pay_ty = request.POST.get("st")
        obj.due_date = EndDate
        if obj.pay_ty == "credit":
            obj.status = "pending"
        else:
            obj.status = "success"
        obj.save()
    return render(request, 'salesentry/salesentry.html',context)


def vw(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM salesentry,custreg WHERE salesentry.cid=custreg.cid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'salesentry/vw_sa.html',context)


def vw_m(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM salesentry,custreg WHERE salesentry.cid=custreg.cid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'salesentry/mg_vw_sa.html',context)


def cus_due_a(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM salesentry,custreg,rawreg WHERE salesentry.cid=custreg.cid and salesentry.product=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'salesentry/cus_due_v_adm.html',context)


def cus_due_m(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM salesentry,custreg,rawreg WHERE salesentry.cid=custreg.cid and salesentry.product=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'salesentry/cus_due_v_m.html',context)