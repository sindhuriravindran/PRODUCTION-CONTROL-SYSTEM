from django.conf.urls import url,include
from salesentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.sales,name='sent'),
    url('^vw/',views.vw,name='vw'),
    url('^vw_m/', views.vw_m, name='vw'),
    url('^cus_due_m/', views.cus_due_m, name='vw'),
    url('^cus_due_ad/', views.cus_due_a, name='vw')
    ]