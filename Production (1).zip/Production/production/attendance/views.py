from django.shortcuts import render
from attendance.models import Attendance
from employreg.models import Employreg
# Create your views here.
def att(request):
    objlist = Employreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Attendance()
        obj.ename = request.POST.get("empname")
        obj.date = request.POST.get("date")
        obj.mrngshift = request.POST.get("shift1")
        obj.noonshift=request.POST.get("shift2")
        obj.save()
    return render(request, 'attendance/attendance.html',context)


def vat(request):
    fid = str(request.session['uid'])
    objlist = Attendance.objects.filter(ename=fid)
    context = {
        'objval': objlist,
    }
    return render(request, 'attendance/viewattendance.html',context)


def a_vat(request):
    # empname
    if request.method == "POST":
        empname = request.POST.get("empname")
        objlist = Employreg.objects.all()
        objlist1 = Attendance.objects.filter(ename=empname)
        context = {
            'objval': objlist,
            'objval1': objlist1,

        }

        return render(request, 'attendance/a_viewattendance.html', context)
    else:
        objlist = Employreg.objects.all()
        context = {
            'objval': objlist,
        }
        return render(request, 'attendance/a_viewattendance.html',context)