from django.apps import AppConfig


class DaybookConfig(AppConfig):
    name = 'daybook'
