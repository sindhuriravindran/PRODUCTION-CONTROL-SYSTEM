from django.shortcuts import render
from daybook.models import Daybook
from employreg.models import Employreg
import datetime
# Create your views here.


def day(request):
    objlist = Employreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Daybook()
        obj.e_id = request.POST.get("eid")
        obj.date = datetime.date.today()
        obj.des = request.POST.get("des")
        obj.save()
    return render(request, 'daybook/m_add.html', context)


def a_v(request):
    date = datetime.date.today()
    objlist = Daybook.objects.filter(date=date)
    context = {
        'objval': objlist,
    }
    return render(request,'daybook/a_v.html',context)


def e_v(request):
    date = datetime.date.today()
    fid = str(request.session['uid'])
    objlist = Daybook.objects.filter(date=date,e_id=fid)
    context = {
        'objval': objlist,
    }
    return render(request,'daybook/e_v.html',context)