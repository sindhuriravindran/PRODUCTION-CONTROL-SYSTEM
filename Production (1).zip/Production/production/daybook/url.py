from django.conf.urls import url,include
from daybook import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.day,name='ote'),
    url('^a_v/',views.a_v,name='vot'),
    url('^e_v/', views.e_v, name='vot'),
]