from django.db import models


class Daybook(models.Model):
    e_id = models.IntegerField()
    date = models.DateField()
    des = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'daybook'
