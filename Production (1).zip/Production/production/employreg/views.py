from django.shortcuts import render
from employreg.models import Employreg
from login.models import Login
# Create your views here.
def ereg(request):
    if request.method == "POST":
        obj = Employreg()
        obj.ename = request.POST.get("empname")
        obj.eaddr = request.POST.get("addressemp")
        obj.phone = request.POST.get("empphone")
        obj.email = request.POST.get("emailemp")
        obj.type = request.POST.get("emptyp")
        obj.basicpay = request.POST.get("basicpay")
        obj.save()
        ob = Login()
        ob.uid = obj.eid
        ob.username=request.POST.get("emailemp")
        ob.password=request.POST.get("pass")
        ob.type = "employee"
        ob.save()
        context = {
            'msg': "succcessfully registered"
        }
        return render(request, 'employreg/employreg.html',context)
    return render(request, 'employreg/employreg.html')