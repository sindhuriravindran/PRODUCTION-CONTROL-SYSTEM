from django.conf.urls import url,include
from employreg import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.ereg,name='ereg')
    ]