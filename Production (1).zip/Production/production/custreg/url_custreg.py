from django.conf.urls import url,include
from custreg import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.cureg,name='cureg')
    ]