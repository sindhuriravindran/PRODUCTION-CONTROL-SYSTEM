from django.conf.urls import url
from receipt import views

urlpatterns=[
    url(r'^$', views.add, name="comp"),
    url(r'^vi/', views.vi, name="comp_view"),
]