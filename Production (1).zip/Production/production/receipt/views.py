from django.shortcuts import render
from receipt.models import Receipt
from custreg.models import Custreg
import datetime
# Create your views here.


def add(request):
    objlist = Custreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Receipt()
        obj.cid =request.POST.get('cid')
        obj.amt = request.POST.get('amt')
        obj.billno = request.POST.get('bill')
        obj.date = datetime.date.today()
        obj.save()
    return render(request, 'receipt/em_re.html',context)


def vi(request):
    objlist = Receipt.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request, 'receipt/vi.html',context)