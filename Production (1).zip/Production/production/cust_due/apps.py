from django.apps import AppConfig


class CustDueConfig(AppConfig):
    name = 'cust_due'
