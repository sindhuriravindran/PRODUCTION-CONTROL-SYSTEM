from django.conf.urls import url,include
from login import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.log,name='log'),
    url('^adminhome/', views.adminhome, name='adminhome'),
    url('^managerhome/', views.managerhome, name='managerhome'),
    url('^employeehome/', views.employeehome, name='employeehome'),
    ]