from django.conf.urls import url
from expense import views

urlpatterns=[
    url(r'^$', views.exp, name="comp"),
    url(r'^v/', views.exp_v, name="comp_view"),
]