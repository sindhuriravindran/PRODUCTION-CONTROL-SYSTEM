from django.apps import AppConfig


class ExpenseConfig(AppConfig):
    name = 'expense'
