from django.shortcuts import render
from expense.models import Expense
# Create your views here.


def exp(request):
    if request.method == "POST":
        obj = Expense()
        obj.eid = str(request.session['uid'])
        obj.exp_amt = request.POST.get('amt')
        obj.details = request.POST.get('des')
        obj.date = request.POST.get('date')
        obj.save()
    return render(request, 'expense/e_ex.html')


def exp_v(request):
    objlist = Expense.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request, 'expense/m_ex.html', context)