from django.conf.urls import url,include
from vehiclereg import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.vreg,name='vreg')
    ]