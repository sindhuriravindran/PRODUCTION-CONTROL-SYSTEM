from django.shortcuts import render
from vehiclereg.models import Vehiclereg
# Create your views here.
def vreg(request):
    if request.method == "POST":
        obj = Vehiclereg()
        obj.vehno = request.POST.get("vehno")
        obj.type = request.POST.get("vehtyp")
        obj.status = "available"
        obj.save()
        context = {
            'msg': "succcessfully registered"
        }
        return render(request, 'vehiclereg/vehiclereg.html',context)
    return render(request, 'vehiclereg/vehiclereg.html')