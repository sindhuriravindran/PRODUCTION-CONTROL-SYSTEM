from django.conf.urls import url,include
from purchaseentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.put,name='put'),
    url('^vw/',views.vw_pur,name='put'),
    url('^ven_due_m/', views.ven_due, name='put'),
    url('^ven_due_ad/', views.ven_due_ad, name='put'),
    ]