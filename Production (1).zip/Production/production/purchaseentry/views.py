from django.shortcuts import render
from purchaseentry.models import Purchaseentry
from vendorreg.models import Vendorreg
from rawreg.models import Rawreg
import datetime
from django.db import connection
from datetime import timedelta,date
# Create your views here.


def put(request):
    task = Vendorreg.objects.all()
    task1 = Rawreg.objects.all()
    context = {
        'task': task,
        'task1': task1,
    }
    if request.method == "POST":
        ven = request.POST.get("vid")
        due = Vendorreg.objects.get(vid=ven)
        day = due.days
        EndDate = date.today() + timedelta(days=day)
        obj = Purchaseentry()
        obj.vid = request.POST.get("vid")
        obj.date = datetime.date.today()
        obj.rid = request.POST.get("rid")
        obj.quantity = request.POST.get("qty")
        obj.cgst = request.POST.get("cgst")
        obj.igst = request.POST.get("igst")
        obj.total = request.POST.get("t")
        obj.discount = request.POST.get("dis")
        obj.gstno = request.POST.get("gs")
        obj.py_ty = request.POST.get("st")
        obj.due_date = EndDate
        if obj.py_ty == "credit":
            obj.status = "pending"
        else:
            obj.status = "success"
        obj.save()
    return render(request, 'purchaseentry/purchaseentry.html', context)


def vw_pur(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM purchaseentry,vendorreg,rawreg WHERE purchaseentry.vid=vendorreg.Vid and purchaseentry.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'purchaseentry/vw_pur.html',context)


def ven_due(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM purchaseentry,vendorreg,rawreg WHERE purchaseentry.vid=vendorreg.Vid and purchaseentry.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'purchaseentry/ven_due_v_mng.html',context)


def ven_due_ad(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM purchaseentry,vendorreg,rawreg WHERE purchaseentry.vid=vendorreg.Vid and purchaseentry.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'purchaseentry/ven_due_v_admin.html',context)