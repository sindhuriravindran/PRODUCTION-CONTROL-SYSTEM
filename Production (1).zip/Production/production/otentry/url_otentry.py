from django.conf.urls import url,include
from otentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.ote,name='ote'),
    url('^vot/',views.vot,name='vot')
    ]