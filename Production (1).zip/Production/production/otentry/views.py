from django.shortcuts import render
from otentry.models import Otentry
from employreg.models import Employreg
# Create your views here.
def ote(request):
    objlist = Employreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Otentry()
        obj.ename = request.POST.get("empname")
        obj.date = request.POST.get("date")
        obj.hours = request.POST.get("hours")
        obj.save()

    return render(request, 'otentry/otentry.html',context)
def vot(request):
    # empname
    if request.method == "POST":
        empname = request.POST.get("empname")


        objlist = Employreg.objects.all()
        objlist1 = Otentry.objects.filter(ename=empname)
        context = {
            'objval': objlist,
            'objval1': objlist1,

        }

        return render(request, 'otentry/viewot.html', context)
    else:
        objlist = Employreg.objects.all()
        context = {
            'objval': objlist,

        }

        return render(request, 'otentry/viewot.html',context)
