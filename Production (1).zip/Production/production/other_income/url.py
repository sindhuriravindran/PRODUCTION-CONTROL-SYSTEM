from django.conf.urls import url
from other_income import views

urlpatterns=[
    url(r'^$', views.inc, name="comp"),
    url(r'^v/', views.v_inc, name="comp_view"),
]