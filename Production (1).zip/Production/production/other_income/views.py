from django.shortcuts import render
from other_income.models import OtherIncome
# Create your views here.


def inc(request):
    if request.method == "POST":
        obj = OtherIncome()
        obj.eid = str(request.session['uid'])
        obj.in_amt = request.POST.get('amt')
        obj.des = request.POST.get('des')
        obj.ddate = request.POST.get('date')
        obj.save()
    return render(request, 'other_income/em_in.html')


def v_inc(request):
    objlist = OtherIncome.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request, 'other_income/mn_in.html', context)