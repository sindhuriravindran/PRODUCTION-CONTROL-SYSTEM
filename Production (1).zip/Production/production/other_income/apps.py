from django.apps import AppConfig


class OtherIncomeConfig(AppConfig):
    name = 'other_income'
