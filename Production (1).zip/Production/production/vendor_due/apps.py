from django.apps import AppConfig


class VendorDueConfig(AppConfig):
    name = 'vendor_due'
