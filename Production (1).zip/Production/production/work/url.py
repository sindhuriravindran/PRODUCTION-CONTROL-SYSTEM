from django.conf.urls import url
from work import views
urlpatterns = [
    url('^$',views.order,name='campr'),
    url('^av/',views.ad_v,name='campview'),
    url('^ev/', views.e_v, name='campview'),
    url(r'^emp_up/(?P<idd>\w+)', views.emp_up, name='emp_up'),
    url('^m_v_s/', views.m_v_s, name='m_v_s'),
    ]