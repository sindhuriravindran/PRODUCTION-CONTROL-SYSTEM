from django.shortcuts import render
from work.models import WorkOr
from custreg.models import Custreg
from employreg.models import Employreg
from django.db import connection


def order(request):
    objlist1 = Custreg.objects.all()
    objlist = Employreg.objects.all()
    context = {
        'objval1': objlist1,
        'objval': objlist,
    }
    if request.method == "POST":
        obj = WorkOr()
        obj.vid = request.POST.get("eid")
        obj.status = "pending"
        obj.cid = request.POST.get("cid")
        obj.work=request.POST.get("work")
        obj.date = request.POST.get("date")
        obj.locaion = request.POST.get("loc")
        obj.save()
    return render(request,'work/m_wk_order.html', context)


def e_v(request):
    fid = str(request.session['uid'])
    objlist1 = WorkOr.objects.filter(vid=fid, status='pending')
    context = {
        'objval1': objlist1,
    }
    return render(request, 'work/emp_update.html', context)


def ad_v(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM work_or,custreg WHERE work_or.cid=custreg.cid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'work/a_v_order.html', context)


def emp_up(request,idd):
    objlist = WorkOr.objects.filter(id=idd)
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = WorkOr.objects.get(id=idd)
        obj.status = request.POST.get("st")
        obj.save()
        return e_v(request)
    return render(request, 'work/emp_update_2.html', context)


def m_v_s(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM work_or,custreg,employreg WHERE work_or.cid=custreg.cid and work_or.vid=employreg.eid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'work/mn_work_sta.html', context)