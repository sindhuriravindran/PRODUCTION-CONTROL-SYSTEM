from django.apps import AppConfig


class WorkConfig(AppConfig):
    name = 'work'
