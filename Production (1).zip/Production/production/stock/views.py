from django.shortcuts import render
from stock.models import Stock
from rawreg.models import Rawreg
from django.db import connection
# Create your views here.


def add(request):
    objlist = Rawreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Stock()
        obj.rid = request.POST.get("rid")
        obj.quantity = request.POST.get("qty")
        obj.save()
    return render(request, 'stock/em_add.html', context)


def av(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM stock,rawreg WHERE stock.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'stock/ad_v.html',context)


def mv(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM stock,rawreg WHERE stock.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'stock/m_v.html',context)


def up(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM stock,rawreg WHERE stock.rid=rawreg.rid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'stock/em_up.html',context)


def upda_2(request, idd):
    objlist = Stock.objects.filter(id=idd)
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Stock.objects.get(id=idd)
        obj.quantity = request.POST.get("qty")
        obj.save()
        return up(request)
    return render(request, 'stock/em_up_2.html', context)


def consu(request, idd):
    objlist = Stock.objects.filter(id=idd)
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Stock.objects.get(id=idd)
        obj.quantity = request.POST.get("qty")
        obj.save()
        return up(request)
    return render(request, 'stock/em_consumption_entry.html', context)


