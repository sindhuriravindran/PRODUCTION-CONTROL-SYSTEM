from django.db import models


class Stock(models.Model):
    rid = models.IntegerField()
    quantity = models.CharField(max_length=500)

    class Meta:
        managed = False
        db_table = 'stock'

