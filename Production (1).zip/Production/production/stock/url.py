from django.conf.urls import url
from stock import views

urlpatterns=[
    url(r'^$', views.add, name="comp"),
    url(r'^av/', views.av, name="comp_view"),
    url(r'^upda_2/(?P<idd>\w+)', views.upda_2, name="upda_2"),
    url(r'^consu/(?P<idd>\w+)', views.consu, name="consu"),
    url(r'^mv/', views.mv, name="reply_view"),
    url(r'^up/', views.up, name="reply_view"),
]