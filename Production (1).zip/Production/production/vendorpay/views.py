from django.shortcuts import render
from vendorpay.models import Vendorpay
from vendorreg.models import Vendorreg
# Create your views here.


def vpay(request):
    objlist = Vendorreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Vendorpay()
        obj.vid = request.POST.get("vid")
        obj.amount = request.POST.get("amt")
        obj.billno = request.POST.get("bill")
        obj.date = request.POST.get("date")
        obj.pay_ty = request.POST.get("st")
        obj.save()
    return render(request, 'vendorpay/vendorpay.html',context)
