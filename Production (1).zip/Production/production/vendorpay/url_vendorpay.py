from django.conf.urls import url,include
from vendorpay import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.vpay,name='vpay')
    ]