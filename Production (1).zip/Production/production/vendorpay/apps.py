from django.apps import AppConfig


class VendorpayConfig(AppConfig):
    name = 'vendorpay'
