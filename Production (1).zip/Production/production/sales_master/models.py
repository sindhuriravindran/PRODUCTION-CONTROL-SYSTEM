from django.db import models


class SalesMaster(models.Model):
    s_id = models.IntegerField()
    cus_id = models.IntegerField()
    t_amt = models.IntegerField()
    date = models.DateField()
    pay_type = models.CharField(max_length=50)
    due_date = models.CharField(max_length=50)
    status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'sales_master'
