from django.apps import AppConfig


class SalesMasterConfig(AppConfig):
    name = 'sales_master'
