from django.conf.urls import url,include
from vendorreg import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.vreg,name='vreg')
    ]