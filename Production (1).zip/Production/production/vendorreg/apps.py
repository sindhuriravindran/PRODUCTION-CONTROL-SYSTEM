from django.apps import AppConfig


class VendorregConfig(AppConfig):
    name = 'vendorreg'
