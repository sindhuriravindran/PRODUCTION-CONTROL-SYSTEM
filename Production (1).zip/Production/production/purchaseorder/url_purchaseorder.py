from purchaseorder import views
from django.conf.urls import url,include

urlpatterns = [
    url('^$',views.puord,name='puord'),
    url('^appr/',views.app,name='app'),
    url('^approve_od/(?P<idd>\w+)',views.approve_od,name='approve_od'),
    url('^reject_od/(?P<idd>\w+)',views.reject_od,name='reject_od'),
    ]