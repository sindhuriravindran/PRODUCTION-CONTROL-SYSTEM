from django.shortcuts import render
from purchaseorder.models import Purchaseorder
from rawreg.models import Rawreg
# Create your views here.
def puord(request):
    objlist=Rawreg.objects.all()
    context={
        'objval':objlist,
    }
    if request.method == "POST":
        obj = Purchaseorder()
        obj.rname = request.POST.get("rname")
        obj.date = request.POST.get("date")
        obj.quantity = request.POST.get("quantity")
        obj.status = "pending"
        obj.save()
        context1 = {
            'msg': "ORDER GENERATED"
        }
        return render(request, 'purchaseorder/purchaseorder.html', context1)
    return render(request, 'purchaseorder/purchaseorder.html',context)

def app(request):
    # objlist = Purchaseorder.objects.all()
    objlist = Purchaseorder.objects.filter(status='pending')
    context = {
        'objval': objlist,
    }

    return render(request, 'purchaseorder/approveorder.html',context)


def approve_od(request,idd):
    obj = Purchaseorder.objects.get(orderno=idd)
    obj.status='approve'
    obj.save()
    objlist = Purchaseorder.objects.filter(status='pending')
    context = {
        'objval': objlist,
        'msg': "Approved"
    }

    return render(request, 'purchaseorder/approveorder.html', context)

def reject_od(request, idd):
    obj = Purchaseorder.objects.get(orderno=idd)
    obj.status = 'reject'
    obj.save()
    objlist = Purchaseorder.objects.filter(status='pending')
    context = {
        'objval': objlist,
        'msg': "Rejected"
    }

    return render(request, 'purchaseorder/approveorder.html', context)




