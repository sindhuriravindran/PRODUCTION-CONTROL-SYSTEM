from django.conf.urls import url,include
from delivery import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.deli,name='ote'),
    url('^a_v/',views.a_v,name='vot'),
    url('^m_v/', views.m_v, name='vot'),
    url('^e_v/', views.e_v, name='vot'),
    url(r'^del_u/(?P<idd>\w+)', views.del_u, name="del_u"),
]