from django.shortcuts import render
from delivery.models import Delivery
from employreg.models import Employreg

# Create your views here.


def deli(request):
    objlist = Employreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Delivery()
        obj.eid = request.POST.get("eid")
        obj.items = request.POST.get("i")
        obj.des = request.POST.get("des")
        obj.status = "pending"
        obj.save()
    return render(request, 'delivery/m_v.html', context)


def a_v(request):
    objlist = Delivery.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'delivery/a_v.html',context)


def m_v(request):
    objlist = Delivery.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'delivery/m_view.html',context)


def e_v(request):
    fid = str(request.session['uid'])
    objlist = Delivery.objects.filter(eid=fid,status="pending")
    context = {
        'objval': objlist,
    }
    return render(request,'delivery/e_d.html',context)


def del_u(request,idd):
    objlist = Delivery.objects.filter(id=idd)
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Delivery.objects.get(id=idd)
        obj.status = request.POST.get("st")
        obj.save()
        return e_v(request)
    return render(request, 'delivery/e_d_2.html', context)

