from django.db import models


class Salaryset(models.Model):
    stid = models.AutoField(primary_key=True)
    emp_type = models.CharField(max_length=20)
    empid = models.IntegerField()
    basicpay = models.IntegerField()
    allowances = models.IntegerField()
    leavepmn = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'salaryset'
