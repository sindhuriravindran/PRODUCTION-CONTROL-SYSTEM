from django.shortcuts import render
from employreg.models import Employreg
from salaryset.models import Salaryset
from django.db import connection

# Create your views here.
def sal(request):
    objlist = Employreg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Salaryset()
        obj.emp_type = request.POST.get("emptyp")
        obj.empid = request.POST.get("eid")
        obj.basicpay = request.POST.get("b")
        obj.allowances = request.POST.get("a")
        obj.leavepmn = request.POST.get("l")
        obj.save()
    return render(request, 'salaryset/salaryset.html',context)


def a_s(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM salaryset,employreg WHERE salaryset.empid=employreg.eid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request, 'salaryset/av.html',context)


def e_s(request):
    fid = str(request.session['uid'])
    objlist = Salaryset.objects.filter(empid=fid)
    context = {
        'objval': objlist,
    }
    return render(request, 'salaryset/ev.html',context)