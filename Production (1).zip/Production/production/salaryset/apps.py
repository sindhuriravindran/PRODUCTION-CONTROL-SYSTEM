from django.apps import AppConfig


class SalarysetConfig(AppConfig):
    name = 'salaryset'
