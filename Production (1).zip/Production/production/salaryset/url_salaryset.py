from django.conf.urls import url,include
from salaryset import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.sal,name='sal'),
    url('^a_s/',views.a_s,name='sal'),
    url('^e_s/', views.e_s, name='sal'),

]