from django.shortcuts import render
from sizechart.models import Sizechart
# Create your views here.
def schrt(request):
    if request.method == "POST":
        obj = Sizechart()
        obj.size = request.POST.get("size")
        obj.stype = request.POST.get("mattyp")
        obj.save()
    return render(request, 'sizechart/sizechart.html')