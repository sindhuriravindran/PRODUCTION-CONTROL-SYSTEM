from django.apps import AppConfig


class LeaveentryConfig(AppConfig):
    name = 'leaveentry'
