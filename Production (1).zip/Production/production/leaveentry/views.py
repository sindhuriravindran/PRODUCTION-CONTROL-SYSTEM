from django.shortcuts import render
from leaveentry.models import Leaveentry
from employreg.models import Employreg

# Create your views here.


def lea(request):
    if request.method == "POST":
        obj = Leaveentry()
        obj.ename = str(request.session['uid'])
        obj.date = request.POST.get("date")
        obj.reason = request.POST.get("reason")
        obj.save()
    return render(request, 'leaveentry/leaveentry.html',)


def vle(request):
    # empname
    if request.method == "POST":
        empname = request.POST.get("empname")


        objlist = Employreg.objects.all()
        objlist1 = Leaveentry.objects.filter(ename=empname)
        context = {
            'objval': objlist,
            'objval1': objlist1,

        }

        return render(request, 'leaveentry/viewleave.html', context)
    else:
        objlist = Employreg.objects.all()
        context = {
            'objval': objlist,

        }

        return render(request, 'leaveentry/viewleave.html',context)


def a_vle(request):
    # empname
    if request.method == "POST":
        empname = request.POST.get("empname")


        objlist = Employreg.objects.all()
        objlist1 = Leaveentry.objects.filter(ename=empname)
        context = {
            'objval': objlist,
            'objval1': objlist1,

        }

        return render(request, 'leaveentry/a_viewleave.html', context)
    else:
        objlist = Employreg.objects.all()
        context = {
            'objval': objlist,

        }

        return render(request, 'leaveentry/a_viewleave.html',context)