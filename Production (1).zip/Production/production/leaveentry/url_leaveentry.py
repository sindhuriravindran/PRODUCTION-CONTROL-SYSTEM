from django.conf.urls import url,include
from leaveentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.lea,name='lea'),
    url('^vie/',views.vle,name='vle'),
    url('^a_vie/',views.a_vle,name='vle')
    ]