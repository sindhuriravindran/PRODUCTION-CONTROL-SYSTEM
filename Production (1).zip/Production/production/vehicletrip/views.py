from django.shortcuts import render
from vehicletrip.models import Vehicletrip
from vehiclereg.models import Vehiclereg
from django.db import connection
# Create your views here.


def vtp(request):
    objlist = Vehiclereg.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Vehicletrip()
        obj.vid = request.POST.get('vid')
        obj.km = request.POST.get('km')
        obj.date = request.POST.get('date')
        obj.des = request.POST.get('des')
        obj.save()
    return render(request, 'vehicletrip/vehicletrip.html',context)


def av(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM vehicletrip,vehiclereg WHERE vehicletrip.vid=vehiclereg.vehid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request,'vehicletrip/a_v.html',context)


def mv(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM vehicletrip,vehiclereg WHERE vehicletrip.vid=vehiclereg.vehid")
    context = {
        'objval': objlist.fetchall(),
    }
    return render(request,'vehicletrip/m_v.html',context)