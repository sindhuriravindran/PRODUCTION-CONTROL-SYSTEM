from django.conf.urls import url,include
from vehicletrip import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.vtp,name='vtp'),
    url('^a_v/', views.av, name='vtp'),
    url('^m_v/', views.mv, name='vtp')
    ]