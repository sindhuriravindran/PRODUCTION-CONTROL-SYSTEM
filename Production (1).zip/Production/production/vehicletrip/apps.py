from django.apps import AppConfig


class VehicletripConfig(AppConfig):
    name = 'vehicletrip'
