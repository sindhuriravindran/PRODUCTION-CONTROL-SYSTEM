from django.apps import AppConfig


class VehicleregConfig(AppConfig):
    name = 'vehiclereg'
