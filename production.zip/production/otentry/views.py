from django.shortcuts import render
from otentry.models import Otentry
# Create your views here.
def ote(request):

    return render(request, 'otentry/otentry.html')
