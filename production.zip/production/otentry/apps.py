from django.apps import AppConfig


class OtentryConfig(AppConfig):
    name = 'otentry'
