"""production URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns





urlpatterns = [
    path('admin/', admin.site.urls),
    url('^attendance/',include('attendance.url_attendance')),
    url('^custreg/',include('custreg.url_custreg')),
    url('^employreg/',include('employreg.url_employreg')),
    url('^leaveentry/',include('leaveentry.url_leaveentry')),
    url('^login/',include('login.url_login')),
    url('^otentry/',include('otentry.url_otentry')),
    url('^purchaseentry/',include('purchaseentry.url_purchaseentry')),
    url('^rawreg/',include('rawreg.url_rawreg')),
    url('^salaryset/',include('salaryset.url_salaryset')),
    url('^salesentry/',include('salesentry.url_salesentry')),
    url('^sizechart/',include('sizechart.url_sizechart')),
    url('^vehiclereg/',include('vehiclereg.url_vehiclereg')),
    url('^vehicletrip/',include('vehicletrip.url_vehicletrip')),
    url('^vendorpay/',include('vendorpay.url_vendorpay')),
    url('^vendorreg/',include('vendorreg.url_vendorreg')),
    url('^purchaseorder/',include('purchaseorder.url_purchaseorder')),
]

urlpatterns+=staticfiles_urlpatterns()