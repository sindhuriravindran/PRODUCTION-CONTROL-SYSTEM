from django.apps import AppConfig


class SalesentryConfig(AppConfig):
    name = 'salesentry'
