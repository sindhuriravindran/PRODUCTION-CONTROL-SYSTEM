from django.conf.urls import url,include
from salesentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.sent,name='sent')
    ]