from django.shortcuts import render

# Create your views here.
def sent(request):
    return render(request, 'salesentry/salesentry.html')