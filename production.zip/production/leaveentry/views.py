from django.shortcuts import render
from leaveentry.models import Leaveentry

# Create your views here.
def lea(request):
    if request.method == "POST":
        obj = Leaveentry()
        obj.eid = request.POST.get("empid")
        obj.date = request.POST.get("date")
        obj.reason = request.POST.get("reason")
        obj.save()
    # else:

    return render(request, 'leaveentry/leaveentry.html')