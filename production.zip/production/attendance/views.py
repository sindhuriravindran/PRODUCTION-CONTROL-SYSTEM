from django.shortcuts import render
from attendance.models import Attendance
from employreg.models import Employreg
# Create your views here.
def att(request):
    if request.method == "POST":
        obj = Attendance()
        obj.eid = request.POST.get("empid")
        obj.date = request.POST.get("date")
        obj.mrngshift = request.POST.get("shift1")
        obj.noonshift=request.POST.get("shift2")
        obj.save()
    return render(request, 'attendance/attendance.html')
def vat(request):
    # empname
    if request.method == "POST":
        empid = request.POST.get("empname")


        objlist = Employreg.objects.all()
        objlist1 = Attendance.objects.filter(eid=empid)
        context = {
            'objval': objlist,
            'objval1': objlist1,

        }

        return render(request, 'attendance/viewattendance.html', context)
    else:
        objlist = Employreg.objects.all()
        context = {
            'objval': objlist,

        }

        return render(request, 'attendance/viewattendance.html',context)