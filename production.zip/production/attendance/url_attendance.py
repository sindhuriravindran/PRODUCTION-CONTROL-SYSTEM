
from django.conf.urls import url,include
from attendance import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.att,name='att'),
    url('^vatt/',views.vat,name='vat')
    ]