from django.apps import AppConfig


class PurchaseorderConfig(AppConfig):
    name = 'purchaseorder'
