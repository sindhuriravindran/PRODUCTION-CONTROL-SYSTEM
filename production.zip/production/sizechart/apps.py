from django.apps import AppConfig


class SizechartConfig(AppConfig):
    name = 'sizechart'
