from django.shortcuts import render

# Create your views here.
def vpay(request):
    return render(request, 'vendorpay/vendorpay.html')
