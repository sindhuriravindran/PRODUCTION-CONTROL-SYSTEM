from django.conf.urls import url,include
from salaryset import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.sal,name='sal')
    ]