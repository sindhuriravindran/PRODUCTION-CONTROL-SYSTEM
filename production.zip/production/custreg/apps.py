from django.apps import AppConfig


class CustregConfig(AppConfig):
    name = 'custreg'
