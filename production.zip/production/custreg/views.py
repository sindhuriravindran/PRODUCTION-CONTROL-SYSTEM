from django.shortcuts import render
from custreg.models import Custreg
# Create your views here.
def cureg(request):
    if request.method == "POST":
        obj = Custreg()
        obj.cname = request.POST.get("cusname")
        obj.caddr = request.POST.get("addresscus")
        obj.email = request.POST.get("emailcust")
        obj.mobileno = request.POST.get("cusphone")
        obj.credlmt = request.POST.get("credit")
        obj.days = request.POST.get("days")
        obj.save()
        context = {
            'msg': "succcessfully registered"
        }
        return render(request, 'custreg/customerreg.html',context)
    return render(request, 'custreg/customerreg.html')