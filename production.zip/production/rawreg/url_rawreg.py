from django.conf.urls import url,include
from rawreg import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.rreg,name='rreg')
    ]