from django.shortcuts import render
from rawreg.models import Rawreg
# Create your views here.
def rreg(request):
    if request.method == "POST":
        obj = Rawreg()
        obj.rname = request.POST.get("mname")
        obj.description = request.POST.get("rdes")
        obj.save()
    return render(request, 'rawreg/rawreg.html')