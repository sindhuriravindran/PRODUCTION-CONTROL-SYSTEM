from django.apps import AppConfig


class RawregConfig(AppConfig):
    name = 'rawreg'
