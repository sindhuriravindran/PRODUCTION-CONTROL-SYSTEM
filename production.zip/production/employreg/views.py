from django.shortcuts import render
from employreg.models import Employreg

# Create your views here.
def ereg(request):
    if request.method == "POST":
        obj = Employreg()
        obj.ename = request.POST.get("empname")
        obj.eaddr = request.POST.get("addressemp")
        obj.phone = request.POST.get("emailemp")
        obj.email = request.POST.get("empphone")
        obj.type = request.POST.get("emptyp")
        obj.basicpay = request.POST.get("basicpay")
        obj.save()
        context = {
            'msg': "succcessfully registered"
        }
        return render(request, 'employreg/employreg.html',context)
    return render(request, 'employreg/employreg.html')