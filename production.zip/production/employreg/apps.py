from django.apps import AppConfig


class EmployregConfig(AppConfig):
    name = 'employreg'
