from django.shortcuts import render
from login.models import Login
# Create your views here.
def log(request):
    if request.method == "POST":
        uname = request.POST.get('uname')
        passw = request.POST.get('pass')
        obj = Login.objects.filter(username=uname, password=passw)

        tp = ""
        for ob in obj:
            tp = ob.type
            uid = ob.uid

            if tp == "admin":
                request.session["admin"] = uid

                return render(request, 'login/adminhome.html')
            elif tp == "manager":
                request.session["manager"] = uid

                return render(request, 'login/managerhome.html')

            elif tp == "employee":
                request.session["employee"] = uid

                return render(request, 'login/employeehome.html')

            else:
                context = {
                    'msg': "invalid credential"
                }
                return render(request, 'login/login.html', context)

    return render(request, 'login/login.html')

def logout(request):

        request.session["uid"] = ''

        return log(request)

def adminhome(request):
    return render(request, 'login/adminhome.html')
def employeehome(request):
    return render(request, 'login/employeehome.html')
def managerhome(request):
    return render(request, 'login/managerhome.html')