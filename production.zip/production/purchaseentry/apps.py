from django.apps import AppConfig


class PurchaseentryConfig(AppConfig):
    name = 'purchaseentry'
