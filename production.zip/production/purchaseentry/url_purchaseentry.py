from django.conf.urls import url,include
from purchaseentry import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.put,name='put')
    ]