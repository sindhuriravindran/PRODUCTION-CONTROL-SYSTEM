from django.shortcuts import render

# Create your views here.
def put(request):
    return render(request, 'purchaseentry/purchaseentry.html')