from django.shortcuts import render

# Create your views here.
def vtp(request):
    return render(request, 'vehicletrip/vehicletrip.html')