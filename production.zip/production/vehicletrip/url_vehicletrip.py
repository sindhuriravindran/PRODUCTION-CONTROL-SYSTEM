from django.conf.urls import url,include
from vehicletrip import views
from django.conf.urls import url

urlpatterns = [
    url('^$',views.vtp,name='vtp')
    ]