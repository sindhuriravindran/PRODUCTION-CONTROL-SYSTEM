from django.shortcuts import render
from vendorreg.models import Vendorreg

# Create your views here.
def vreg(request):
    if request.method == "POST":
        obj = Vendorreg()
        obj.vname = request.POST.get("vname")
        obj.address = request.POST.get("addressemp")
        obj.email = request.POST.get("emailemp")
        obj.officeno = request.POST.get("venoffice")
        obj.mobileno = request.POST.get("venmob")
        obj.creditlimit = request.POST.get("credit")
        obj.days = request.POST.get("days")
        obj.save()
        context={
            'msg': "succcessfully registered"
        }
        return render(request, 'vendorreg/vendorreg.html',context)
    return render(request,'vendorreg/vendorreg.html')